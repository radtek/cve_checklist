 set heading OFF termout ON trimout ON feedback OFF
 set pagesize 0
 spool mitigate_35619_3.sql
 select 'execute dbms_java.revoke_permission ('''||user || ''',''' || name ||''',''' || action ||''','''|| enabled || ''');' from dba_java_policy where grantee IN (SELECT USERNAME FROM DBA_USERS WHERE PROFILE NOT IN ('DBS_SERVICES_PROFILE','SYSTEM_ACCOUNTS','DEFAULT'));
 select 'execute dbms_java.DELETE_PERMISSION ('''||seq || ''');' from dba_java_policy where grantee IN (SELECT USERNAME FROM DBA_USERS WHERE PROFILE NOT IN ('DBS_SERVICES_PROFILE','SYSTEM_ACCOUNTS','DEFAULT','C##SYSTEM_ACCOUNTS','C##DBS_SERVICES_PROFILE'));
 spool off;

