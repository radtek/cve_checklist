set heading OFF termout ON trimout ON feedback OFF
set pagesize 0
SELECT comp_name FROM dba_registry where upper(comp_name) like '%JAVA%';
