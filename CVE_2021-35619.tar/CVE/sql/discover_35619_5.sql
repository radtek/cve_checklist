set heading OFF termout ON trimout ON feedback OFF
set pagesize 0
SELECT OS_USERNAME FROM SYS.JAVA\$RUNTIME\$EXEC\$USER\$ WHERE OWNER#=0;
