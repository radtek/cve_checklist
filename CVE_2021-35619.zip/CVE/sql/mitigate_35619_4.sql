set heading OFF termout ON trimout ON feedback OFF
set pagesize 0
spool mitigate_35619_4.sql
SELECT 'REVOKE '|| PRIVILEGE ||' ON ' || TABLE_NAME||' FROM ' || GRANTEE || ';'  FROM DBA_TAB_PRIVS WHERE GRANTEE='PUBLIC' AND PRIVILEGE='EXECUTE' AND TABLE_NAME IN ('DBMS_JAVA','DBMS_JAVA_TEST');
spool off;

