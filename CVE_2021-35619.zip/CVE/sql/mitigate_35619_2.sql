 set heading OFF termout ON trimout ON feedback OFF
 set pagesize 0
 spool mitigate_35619_2.sql
 select trim(TYPE_NAME)||' -- '||trim(NAME)||' -- '||trim(action) "Perm. granted to User/Role" from dba_java_policy where grantee IN (SELECT USERNAME FROM DBA_USERS WHERE PROFILE NOT IN ('DBS_SERVICES_PROFILE','SYSTEM_ACCOUNTS','DEFAULT','C##SYSTEM_ACCOUNTS','C##DBS_SERVICES_PROFILE'));
 spool off;

