set heading OFF termout ON trimout ON feedback OFF
set pagesize 0
select detected_usages from DBA_FEATURE_USAGE_STATISTICS where name like '%Java%';
